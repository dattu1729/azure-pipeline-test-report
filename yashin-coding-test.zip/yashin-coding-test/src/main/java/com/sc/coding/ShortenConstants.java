package com.sc.coding;

public class ShortenConstants {

    public static final String CONST_ZERO="0";

    public static final String CONST_SPACE=" ";

    public static final String CONST_SPLIT_PATTERN="\\.";

    public static final String CONST_DOT=".";

    public static final String CONST_EMPTY="";







}
