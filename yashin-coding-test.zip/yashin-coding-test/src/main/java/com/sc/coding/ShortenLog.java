package com.sc.coding;

import java.util.Stack;

public class ShortenLog {


    public String shortenLog(String pattern, String loggerName) {

        if(pattern ==null || pattern.isEmpty()){
            return "Invalid Pattern";
        }

        if(loggerName ==null || loggerName.isEmpty()){
            return "Invalid LoggerName";
        }

        if (pattern.equals(ShortenConstants.CONST_ZERO)) {
            return shortenLogForZeroPattern(loggerName);
        }

        if (pattern.equals(ShortenConstants.CONST_SPACE) || Integer.parseInt(pattern) < 0) {
            return shortenLogForNegativeAndBlankPattern(loggerName);
        }

        if (loggerName.length() < Integer.parseInt(pattern)) {
            return shortenLogLengthLessThanPatternLength(loggerName);
        }

        if (loggerName.length() > Integer.parseInt(pattern)) {
            return shortenLogForPatternLengthLessThanLogName(Integer.parseInt(pattern), loggerName);
        }


        return null;
    }

    public String shortenLogForZeroPattern(String loggerName) {
        String[] listOfString = loggerName.split(ShortenConstants.CONST_SPLIT_PATTERN);
        System.out.println(listOfString);
        return listOfString[listOfString.length - 1];
    }

    public String shortenLogForNegativeAndBlankPattern(String loggerName) {
        return loggerName;
    }

    public String shortenLogLengthLessThanPatternLength(String logName) {
        return logName;
    }


    public String shortenLogForPatternLengthLessThanLogName(int patternLength, String logName) {
        String[] listOfString = logName.split(ShortenConstants.CONST_SPLIT_PATTERN);
        String result = ShortenConstants.CONST_EMPTY;
        for (int i = 0; i < listOfString.length - 1; i++) {
            if (getLength(listOfString) > patternLength) {
                listOfString[i] = listOfString[i].substring(0, 1);
            }
        }

        for (int i = 0; i < listOfString.length; i++) {
            if (i == listOfString.length - 1) {
                result = result + listOfString[i];
            } else {
                result = result + listOfString[i] + ShortenConstants.CONST_DOT;
            }
        }


        return result;
    }


    public int getLength(String[] listOfString) {
        String result = ShortenConstants.CONST_EMPTY;
        for (int i = 0; i < listOfString.length; i++) {
            result = result + listOfString[i] + ShortenConstants.CONST_DOT;
        }

        return result.length();
    }


    public static void main(String[] args) {
        ShortenLog shortLog = new ShortenLog();
        System.out.println(shortLog.shortenLog("0", "com.scb.teng.MSVC"));
        System.out.println(shortLog.shortenLog(" ", "com.scb.teng.MSVC"));
        System.out.println(shortLog.shortenLog("-2", "com.scb.teng.MSVC"));
        System.out.println(shortLog.shortenLog("6", "com.scb.teng.MSVC"));
        System.out.println(shortLog.shortenLog("6", "com.scb.teng.interview.MSVC"));
        System.out.println(shortLog.shortenLog("6", "com.scb.teng.interview.handson.MSVC"));

        System.out.println(shortLog.shortenLog("14", "com.scb.teng.MSVC"));
        System.out.println(shortLog.shortenLog("14", "com.scb.teng.interview.ISVC"));
        System.out.println(shortLog.shortenLog("14", "com.scb.teng.interview.handson.HSVC"));

        System.out.println(shortLog.shortenLog("16", "com.scb.teng.MSVC"));
        System.out.println(shortLog.shortenLog("16", "com.scb.teng.interview.MSVC"));
        System.out.println(shortLog.shortenLog("16", "com.scb.teng.interview.handson.MSVC"));

    }


}
