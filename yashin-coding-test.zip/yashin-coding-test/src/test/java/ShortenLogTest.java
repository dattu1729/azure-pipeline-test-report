import com.sc.coding.ShortenLog;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ShortenLogTest {


    private ShortenLog shortenLog;


    @Before
    public void setup() {
        shortenLog = new ShortenLog();
    }

    @Test
    public void testPatternLengthZero() {
        Assert.assertEquals("MSVC", shortenLog.shortenLog("0", "com.scb.teng.MSVC"));
        Assert.assertEquals("ISvc", shortenLog.shortenLog("0", "com.scb.teng.interview.ISvc"));
        Assert.assertEquals("HSvc", shortenLog.shortenLog("0", "com.scb.teng.interview.handson.HSvc"));
    }

    @Test
    public void testPatternLengthNegativeOrBlank() {
        Assert.assertEquals("com.scb.teng.MSVC", shortenLog.shortenLog("-1", "com.scb.teng.MSVC"));
        Assert.assertEquals("com.scb.teng.interview.ISvc", shortenLog.shortenLog("-2", "com.scb.teng.interview.ISvc"));
        Assert.assertEquals("com.scb.teng.interview.handson.HSvc", shortenLog.shortenLog(" ", "com.scb.teng.interview.handson.HSvc"));
    }

    @Test
    public void testPatternLengthLessThanLogName() {
        Assert.assertEquals("c.s.t.MSVC", shortenLog.shortenLog("6", "com.scb.teng.MSVC"));
        Assert.assertEquals("c.s.t.i.ISvc", shortenLog.shortenLog("6", "com.scb.teng.interview.ISvc"));
        Assert.assertEquals("c.s.t.i.h.HSvc", shortenLog.shortenLog("6", "com.scb.teng.interview.handson.HSvc"));

        Assert.assertEquals("c.s.teng.MSVC", shortenLog.shortenLog("14", "com.scb.teng.MSVC"));
        Assert.assertEquals("c.s.t.i.ISvc", shortenLog.shortenLog("14", "com.scb.teng.interview.ISvc"));
        Assert.assertEquals("c.s.t.i.h.HSvc", shortenLog.shortenLog("14", "com.scb.teng.interview.handson.HSvc"));

        Assert.assertEquals("c.scb.teng.MSVC", shortenLog.shortenLog("16", "com.scb.teng.MSVC"));
        Assert.assertEquals("c.s.t.i.ISvc", shortenLog.shortenLog("16", "com.scb.teng.interview.ISvc"));
        Assert.assertEquals("c.s.t.i.h.HSvc", shortenLog.shortenLog("16", "com.scb.teng.interview.handson.HSvc"));


        Assert.assertEquals("com.scb.teng.MSVC", shortenLog.shortenLog("26", "com.scb.teng.MSVC"));
        Assert.assertEquals("c.scb.teng.interview.ISvc", shortenLog.shortenLog("26", "com.scb.teng.interview.ISvc"));
        Assert.assertEquals("c.s.t.i.handson.HSvc", shortenLog.shortenLog("26", "com.scb.teng.interview.handson.HSvc"));


    }


    @Test
    public void testPatternLengthGreaterThanLogName() {
        Assert.assertEquals("com.scb.teng.MSVC", shortenLog.shortenLog("36", "com.scb.teng.MSVC"));
        Assert.assertEquals("com.scb.teng.interview.ISvc", shortenLog.shortenLog("36", "com.scb.teng.interview.ISvc"));
        Assert.assertEquals("com.scb.teng.interview.handson.HSvc", shortenLog.shortenLog("36", "com.scb.teng.interview.handson.HSvc"));

    }

    @Test
    public void testInvalidPattern() {
        Assert.assertEquals("Invalid Pattern", shortenLog.shortenLog(null, "com.scb.teng.MSVC"));
        Assert.assertEquals("Invalid Pattern", shortenLog.shortenLog("", "com.scb.teng.MSVC"));
    }

    @Test
    public void testInvalidLogName() {
        Assert.assertEquals("Invalid LoggerName", shortenLog.shortenLog("2", null));
        Assert.assertEquals("Invalid LoggerName", shortenLog.shortenLog("2", ""));
    }


}
