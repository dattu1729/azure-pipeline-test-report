import org.junit.Test;

public class Sample {
    @Test
    public void test() {
        System.out.println("sample");
    }

}
