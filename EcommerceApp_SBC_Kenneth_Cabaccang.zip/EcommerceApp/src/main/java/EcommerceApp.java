import java.util.ArrayList;
import java.util.List;

class Product {
    private String productId;
    private String name;
    private double price;
    private int availabilityQuantity;

    public Product(String productId, String name, double price, int availabilityQuantity) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.availabilityQuantity = availabilityQuantity;
    }

    public String getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getAvailabilityQuantity() {
        return availabilityQuantity;
    }
}

class Customer {
    private String customerId;
    private String name;
    private String email;

    public Customer(String customerId, String name, String email) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}

class Order {
    private int orderId;
    private Customer customer;
    private List<Product> products;

    public Order(int orderId, Customer customer) {
        this.orderId = orderId;
        this.customer = customer;
        this.products = new ArrayList<>();
    }

    public String getOrderId() {
        return java.util.UUID.randomUUID().toString();
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public double calculateTotal() {
        double total = 0;
        for (Product product : products) {
            total += product.getPrice();
        }
        return total;
    }
}

class OrderService {
    private List<Order> orders;

    public OrderService() {
        orders = new ArrayList<>();
    }

    public void placeOrder(Customer customer, List<Product> products) {
        int orderId = orders.size() + 1;
        Order order = new Order(orderId, customer);
        for (Product product : products) {
            order.addProduct(product);
        }
        orders.add(order);
    }

    public List<Order> getAllOrders() {
        return orders;
    }

    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        products.add(new Product("prod-01", "Keyboard TLS", 49.5, 2));
        products.add(new Product("prod-02", "Keyboard Full Size", 59,3));
        return products;
    }
}

public class EcommerceApp {
    public static void main(String[] args) {


        OrderService orderService = new OrderService();

        //Retrieve products
        System.out.println("=============PRODUCT LIST=============");
        orderService.getProducts();
        System.out.println(orderService.getProducts());

        //Ordering by customer
        Customer customer = new Customer("cust-01", "Ada L", "ada.l@email.com");
        orderService.placeOrder(customer, orderService.getProducts());

        List<Order> allOrders = orderService.getAllOrders();
        for (Order order : allOrders) {
            System.out.println("=============ORDER LIST=============");
            System.out.println("Order ID: " + order.getOrderId());
            System.out.println("Customer: " + order.getCustomer().getName());
            System.out.println("CustomerID: "+ order.getCustomer().getCustomerId());
            System.out.println("Products in the order:");
            for (Product product : order.getProducts()) {
                System.out.println(product.getProductId()+" " + product.getName() + " - $" + product.getPrice());
            }
            System.out.println("Total Price: $" + order.calculateTotal());
            System.out.println();
        }
    }
}
